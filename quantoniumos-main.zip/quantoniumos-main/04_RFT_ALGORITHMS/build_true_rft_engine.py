#!/usr/bin/env python3
"""
Build script for True RFT Engine - Symbolic Resonance Kernel
"""
import pybind11
from pybind11.setup_helpers import Pybind11Extension, build_ext
from setuptools import setup

ext_modules = [
    Pybind11Extension(
        "true_rft_engine_bindings",
        [
            "true_rft_engine_bindings.cpp",
        ],
        include_dirs=[
            pybind11.get_cmake_dir(),
        ],
        cxx_std=17,
        define_macros=[("NDEBUG", None)],
    ),
]

setup(
    name="true_rft_engine",
    ext_modules=ext_modules,
    cmdclass={"build_ext": build_ext},
    zip_safe=False,
)
