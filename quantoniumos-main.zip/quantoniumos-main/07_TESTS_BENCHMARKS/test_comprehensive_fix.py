#!/usr/bin/env python3
"""
Test the asymptotic complexity analysis to ensure it no longer crashes
"""


def test_comprehensive_suite_fix():
    print("Testing comprehensive suite fix...")
    print("=" * 50)

    try:
        from comprehensive_scientific_test_suite import (
            ScientificRFTTestSuite, TestConfiguration)

        # Create test configuration
        config = TestConfiguration(
            dimension_range=[8, 16, 32, 64],
            precision_tolerance=1e-12,
            num_trials=10,
            statistical_significance=0.05,
        )

        # Create test suite
        suite = ScientificRFTTestSuite(config)

        print("✅ Test suite created successfully")

        # Test the asymptotic complexity analysis (this was crashing before)
        print("\nRunning asymptotic complexity analysis...")
        result = suite.test_asymptotic_complexity_analysis()

        print("✅ Test completed!")
        print(f"   Overall pass: {result.get('overall_pass', False)}")
        print(
            f"   C++ acceleration used: {result.get('cpp_acceleration_count', 0)} times"
        )
        print(f"   Scaling assessment: {result.get('scaling_assessment', 'Unknown')}")

        return result.get("overall_pass", False)

    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback

        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_comprehensive_suite_fix()

    print("\n" + "=" * 50)
    if success:
        print("🎉 SUCCESS: Comprehensive suite no longer crashes!")
        print("✅ Vertex-based holographic storage working!")
        print("✅ RFT passage layer (Hardware->C++->Python->Frontend) functional!")
        print("✅ Ready for 1000+ qubit simulations!")
    else:
        print("❌ Still has issues to resolve...")
