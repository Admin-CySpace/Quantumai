||#!/usr/bin/env python3
"""
COMPREHENSIVE RFT-BASED CRYPTOGRAPHIC STATISTICAL TEST SUITE This script runs NIST SP 800-22 and Dieharder statistical tests on: 1. RFT-enhanced resonance encryption output 2. RFT-based geometric waveform hash output 3. Combined RFT crypto pipeline output Tests your actual working implementations: - optimized_resonance_encrypt/decrypt (the fixed one with ~50% avalanche) - GeometricWaveformHash with RFT basis - Combines both for ultimate statistical strength assessment INDEPENDENT VALIDATION - No dependency on crypto_secure module
"""
"""
import os
import sys
import time
import hashlib
import subprocess
import secrets
import struct from datetime
import datetime from typing
import List, Dict, Any, Tuple
import json

# Add core encryption modules to path sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'core', 'encryption'))
try: from optimized_resonance_encrypt
import optimized_resonance_encrypt, optimized_resonance_decrypt
print("✓ Using optimized_resonance_encrypt (the working one)")
except ImportError:
print("✗ Could not
import optimized_resonance_encrypt") sys.exit(1)
try: from geometric_waveform_hash
import GeometricWaveformHash
print("✓ Using GeometricWaveformHash with RFT")
except ImportError:
print("✗ Could not
import GeometricWaveformHash") sys.exit(1)

class ComprehensiveRFTCryptoTester: """
    Comprehensive statistical testing of RFT-based cryptographic primitives
"""
"""
    def __init__(self, sample_size_mb: int = 25):
        self.sample_size_bits = sample_size_mb * 1024 * 1024 * 8
        self.sample_size_bytes = sample_size_mb * 1024 * 1024
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.results_dir = os.path.join("test_results", "rft_crypto_stats",
        self.timestamp) os.makedirs(
        self.results_dir, exist_ok=True)
        print(f"🔬 RFT Crypto Statistical Testing Suite")
        print(f"📁 Results directory: {
        self.results_dir}")
        print(f"📏 Sample size: {sample_size_mb}MB ({
        self.sample_size_bits:,} bits)")
        print("=" * 70)
    def test_rft_encryption_randomness(self) -> str: """
        Generate test vector using RFT-enhanced resonance encryption
"""
"""
        print("🔐 Testing RFT-Enhanced Resonance Encryption Randomness")
        print("-" * 50) output_file = os.path.join(
        self.results_dir, "rft_encryption_test_vector.bin")

        # Use a variety of keys to ensure we're not testing a single key's properties keys = [ "quantum_resonance_test_key_001", "geometric_waveform_key_002", "rft_enhanced_crypto_key_003", "avalanche_test_key_004", "statistical_analysis_key_005" ]
        print(f"Generating {
        self.sample_size_bytes:,} bytes using {len(keys)} different keys...") with open(output_file, "wb") as f: bytes_written = 0 key_index = 0 chunk_size = 64 * 1024 # 64KB chunks
        while bytes_written <
        self.sample_size_bytes:

        # Rotate through keys to avoid single-key bias current_key = keys[key_index % len(keys)] key_index += 1

        # Generate varied plaintext (not just random - real-world like) plaintext_types = [

        # Structured data "A" * min(chunk_size,
        self.sample_size_bytes - bytes_written),

        # Semi-random ''.join([chr(32 + (i % 95))
        for i in range(min(chunk_size,
        self.sample_size_bytes - bytes_written))]),

        # Random bytes as string secrets.token_hex(min(chunk_size//2, (
        self.sample_size_bytes - bytes_written)//2)),

        # Pattern-based ("0123456789ABCDEF" * (min(chunk_size,
        self.sample_size_bytes - bytes_written) // 16 + 1))[:min(chunk_size,
        self.sample_size_bytes - bytes_written)], ] plaintext = plaintext_types[key_index % len(plaintext_types)]
        try:

        # Encrypt using RFT-enhanced resonance encryption encrypted_data = optimized_resonance_encrypt(plaintext, current_key)

        # Extract just the payload (skip signature/token for pure randomness test)
        if len(encrypted_data) > 40:

        # Skip 8-byte sig + 32-byte token payload = encrypted_data[40:] write_amount = min(len(payload),
        self.sample_size_bytes - bytes_written) f.write(payload[:write_amount]) bytes_written += write_amount
        if bytes_written % (1024 * 1024) == 0:

        # Every 1MB progress = (bytes_written /
        self.sample_size_bytes) * 100
        print(f" Generated {bytes_written // (1024*1024)}MB... ({progress:.1f}%)") except Exception as e:
        print(f" ⚠️ Error with key {current_key}: {e}") continue
        print(f"✅ Generated {bytes_written:,} bytes of RFT-encrypted data")
        return output_file
    def test_rft_geometric_hash_randomness(self) -> str: """
        Generate test vector using RFT-based geometric waveform hash
"""
"""
        print("\n🔶 Testing RFT-Based Geometric Waveform Hash Randomness")
        print("-" * 50) output_file = os.path.join(
        self.results_dir, "rft_geometric_hash_test_vector.bin")
        print(f"Generating {
        self.sample_size_bytes:,} bytes using RFT geometric hashing...") with open(output_file, "wb") as f: bytes_written = 0 counter = 0
        while bytes_written <
        self.sample_size_bytes:

        # Create varied waveforms for hashing waveform_length = 256 + (counter % 768) # 256-1024 samples

        # Generate different types of waveforms waveform_type = counter % 5
        if waveform_type == 0:

        # Sine wave with noise
import math waveform = [math.sin(2 * math.pi * i / waveform_length) + 0.1 * math.sin(2 * math.pi * i * 7 / waveform_length)
        for i in range(waveform_length)]
        el
        if waveform_type == 1:

        # Random waveform waveform = [secrets.randbits(32) / (2**32)
        for _ in range(waveform_length)]
        el
        if waveform_type == 2:

        # Step function waveform = [1.0
        if i % 16 < 8 else -1.0
        for i in range(waveform_length)]
        el
        if waveform_type == 3:

        # Chirp signal waveform = [math.sin(2 * math.pi * i * i / (waveform_length * waveform_length))
        for i in range(waveform_length)]
        else:

        # Structured pattern waveform = [(i % 100) / 50.0 - 1.0
        for i in range(waveform_length)]
        try:

        # Hash using RFT-based geometric waveform hasher hasher = GeometricWaveformHash(waveform) hash_bytes = hasher.get_hash()

        # Also get the topological signature as additional entropy topo_sig = hasher.get_topological_signature() topo_bytes = struct.pack('d', topo_sig)

        # Convert float to 8 bytes combined = hash_bytes + topo_bytes write_amount = min(len(combined),
        self.sample_size_bytes - bytes_written) f.write(combined[:write_amount]) bytes_written += write_amount counter += 1
        if bytes_written % (1024 * 1024) == 0:

        # Every 1MB progress = (bytes_written /
        self.sample_size_bytes) * 100
        print(f" Generated {bytes_written // (1024*1024)}MB... ({progress:.1f}%) - {counter} hashes computed") except Exception as e:
        print(f" ⚠️ Hash error at counter {counter}: {e}") counter += 1 continue
        print(f"✅ Generated {bytes_written:,} bytes from {counter} RFT geometric hashes")
        return output_file
    def test_combined_rft_crypto_pipeline(self) -> str: """
        Test the combined RFT encryption + geometric hash pipeline
"""
"""
        print("\n Testing Combined RFT Crypto Pipeline")
        print("-" * 50) output_file = os.path.join(
        self.results_dir, "rft_combined_pipeline_test_vector.bin")
        print(f"Generating {
        self.sample_size_bytes:,} bytes using RFT encrypt->hash pipeline...") keys = ["pipeline_key_" + str(i)
        for i in range(10)] with open(output_file, "wb") as f: bytes_written = 0 counter = 0
        while bytes_written <
        self.sample_size_bytes: current_key = keys[counter % len(keys)]

        # Create input data input_size = 1024 + (counter % 3072) # 1KB-4KB inputs input_data = secrets.token_hex(input_size // 2)
        try:

        # Step 1: RFT-enhanced encryption encrypted_data = optimized_resonance_encrypt(input_data, current_key)

        # Step 2: Convert encrypted bytes to waveform
        if len(encrypted_data) > 40: payload = encrypted_data[40:]

        # Skip signature/token waveform = [(b / 255.0) * 2.0 - 1.0
        for b in payload[:512]]

        # Normalize to [-1,1]
        if len(waveform) >= 64:

        # Minimum for meaningful RFT

        # Step 3: RFT-based geometric hash of encrypted waveform hasher = GeometricWaveformHash(waveform) hash_output = hasher.get_hash() topo_sig = hasher.get_topological_signature() topo_bytes = struct.pack('d', topo_sig)

        # Step 4: Final encryption of the hash (double-encrypt pipeline) final_key = hashlib.sha256((current_key + "_final").encode()).hexdigest()[:16] final_encrypted = optimized_resonance_encrypt(hash_output.hex(), final_key)

        # Extract final payload
        if len(final_encrypted) > 40: final_payload = final_encrypted[40:] combined_output = final_payload + topo_bytes write_amount = min(len(combined_output),
        self.sample_size_bytes - bytes_written) f.write(combined_output[:write_amount]) bytes_written += write_amount counter += 1
        if bytes_written % (1024 * 1024) == 0:

        # Every 1MB progress = (bytes_written /
        self.sample_size_bytes) * 100
        print(f" Generated {bytes_written // (1024*1024)}MB... ({progress:.1f}%) - {counter} pipeline ops") except Exception as e:
        print(f" ⚠️ Pipeline error at counter {counter}: {e}") counter += 1 continue
        print(f"✅ Generated {bytes_written:,} bytes from {counter} RFT pipeline operations")
        return output_file
    def run_dieharder_tests(self, data_file: str, test_name: str) -> Dict[str, Any]: """
        Run Dieharder statistical tests on binary data file
"""
"""
        print(f"\n Running Dieharder Tests on {test_name}")
        print("-" * 50) results = {}

        # Run comprehensive Dieharder test suite cmd = ["dieharder", "-a", "-f", data_file]
        try:
        print("Running full Dieharder battery (this may take several minutes)...") start_time = time.time() output = subprocess.check_output(cmd, text=True, timeout=1800) # 30 min timeout duration = time.time() - start_time
        print(f"✅ Dieharder completed in {duration:.1f} seconds")

        # Parse results tests =
        self.parse_dieharder_output(output) results = { "test_name": test_name, "tests": tests, "duration_seconds": duration, "raw_output": output, "success": True }

        # Summary passed = len([t
        for t in tests
        if t.get("result") == "PASSED"]) failed = len([t
        for t in tests
        if t.get("result") == "FAILED"]) weak = len([t
        for t in tests
        if t.get("result") == "WEAK"])
        print(f" Results: {passed} PASSED, {weak} WEAK, {failed} FAILED") except subprocess.TimeoutExpired: results = {"error": "Test timed out after 30 minutes", "success": False} except subprocess.CalledProcessError as e: results = {"error": f"Test failed: {e}", "success": False} except Exception as e: results = {"error": f"Unexpected error: {e}", "success": False}
        return results
    def parse_dieharder_output(self, output: str) -> List[Dict[str, Any]]: """
        Parse Dieharder test results from output
"""
        """ tests = []
        for line in output.split('||n'): line = line.strip()
        if not line or '|' not in line: continue

        # Look for result lines with format: test_name|ntup|tsamples|psamples|p-value|Assessment parts = [p.strip()
        for p in line.split('|||')]
        if len(parts) >= 6 and parts[0] and parts[4]:
        try: test_name = parts[0] p_value_str = parts[4] assessment = parts[5]
        if len(parts) > 5 else ""

        # Extract p-value (may have scientific notation)
        if p_value_str and p_value_str != "p-value":
        try: p_value = float(p_value_str)
        except: p_value = 0.0

        # Determine result if "PASSED" in assessment: result = "PASSED"
        elif "FAILED" in assessment: result = "FAILED"
        elif "WEAK" in assessment: result = "WEAK"
        else: result = "UNKNOWN" tests.append({ "name": test_name, "p_value": p_value, "result": result, "assessment": assessment })
        except: continue
        return tests
    def basic_entropy_analysis(self, data_file: str, test_name: str) -> Dict[str, float]: """
        Basic entropy and statistical analysis
"""
"""
        print(f"\n📈 Basic Statistical Analysis of {test_name}")
        print("-" * 50) with open(data_file, 'rb') as f: data = f.read()

        # Byte frequency analysis byte_counts = [0] * 256
        for byte in data: byte_counts[byte] += 1 total_bytes = len(data)

        # Shannon entropy entropy = 0.0
        for count in byte_counts:
        if count > 0: p = count / total_bytes entropy -= p * (p.bit_length() - 1) # log2 approximation

        # Chi-square test (expected: 256/256 = uniform distribution) expected = total_bytes / 256 chi_square = sum((count - expected) ** 2 / expected
        for count in byte_counts)

        # Mean and variance mean = sum(data) / len(data) variance = sum((b - mean) ** 2
        for b in data) / len(data)
        print(f" Shannon Entropy: {entropy:.6f} bits/byte (ideal: ~8.0)")
        print(f" Mean: {mean:.2f} (ideal: ~127.5)")
        print(f" Variance: {variance:.2f}")
        print(f" Chi-Square: {chi_square:.2f}")
        return { "shannon_entropy": entropy, "mean": mean, "variance": variance, "chi_square": chi_square }
    def run_full_test_suite(self): """
        Run the complete RFT cryptographic statistical test suite
"""
        """ start_time = time.time() results = { "timestamp":
        self.timestamp, "sample_size_mb":
        self.sample_size_bytes // (1024 * 1024), "test_results": {} }

        # Test 1: RFT-Enhanced Resonance Encryption
        print("\n" + "="*70) rft_encryption_file =
        self.test_rft_encryption_randomness() encryption_entropy =
        self.basic_entropy_analysis(rft_encryption_file, "RFT Encryption") encryption_dieharder =
        self.run_dieharder_tests(rft_encryption_file, "RFT Encryption") results["test_results"]["rft_encryption"] = { "entropy_analysis": encryption_entropy, "dieharder_tests": encryption_dieharder }

        # Test 2: RFT-Based Geometric Hash
        print("\n" + "="*70) geometric_hash_file =
        self.test_rft_geometric_hash_randomness() hash_entropy =
        self.basic_entropy_analysis(geometric_hash_file, "RFT Geometric Hash") hash_dieharder =
        self.run_dieharder_tests(geometric_hash_file, "RFT Geometric Hash") results["test_results"]["rft_geometric_hash"] = { "entropy_analysis": hash_entropy, "dieharder_tests": hash_dieharder }

        # Test 3: Combined RFT Pipeline
        print("\n" + "="*70) pipeline_file =
        self.test_combined_rft_crypto_pipeline() pipeline_entropy =
        self.basic_entropy_analysis(pipeline_file, "RFT Combined Pipeline") pipeline_dieharder =
        self.run_dieharder_tests(pipeline_file, "RFT Combined Pipeline") results["test_results"]["rft_combined_pipeline"] = { "entropy_analysis": pipeline_entropy, "dieharder_tests": pipeline_dieharder }

        # Overall timing total_duration = time.time() - start_time results["total_duration_seconds"] = total_duration

        # Save comprehensive results results_file = os.path.join(
        self.results_dir, "comprehensive_rft_statistical_results.json") with open(results_file, 'w') as f: json.dump(results, f, indent=2)

        # Generate summary report
        self.generate_summary_report(results)
        print(f"\n✅ COMPLETE! Total test time: {total_duration/60:.1f} minutes")
        print(f"📄 Full results saved to: {results_file}")
        return results
    def generate_summary_report(self, results: Dict[str, Any]): """
        Generate human-readable summary report
"""
        """ report_file = os.path.join(
        self.results_dir, "STATISTICAL_TEST_SUMMARY.md") with open(report_file, 'w') as f: f.write("

        # RFT-Based Cryptography Statistical Test Results\n\n") f.write(f"**Test Date:** {
        self.timestamp}\n") f.write(f"**Sample Size:** {results['sample_size_mb']} MB\n") f.write(f"**Total Duration:** {results['total_duration_seconds']/60:.1f} minutes\n\n") f.write("#

        # Test Components Analyzed\n\n") f.write("1. **RFT-Enhanced Resonance Encryption** - Your fixed optimized_resonance_encrypt\n") f.write("2. **RFT-Based Geometric Waveform Hash** - Novel geometric hash with RFT basis\n") f.write("3. **Combined RFT Pipeline** - Encryption->Hash->Re-encryption pipeline\n\n") for test_name, test_data in results["test_results"].items(): f.write(f"## {test_name.replace('_', ' ').title()}\n\n")

        # Entropy analysis entropy = test_data["entropy_analysis"] f.write("##

        # Entropy Analysis\n") f.write(f"- **Shannon Entropy:** {entropy['shannon_entropy']:.6f} bits/byte (ideal: ~8.0)\n") f.write(f"- **Mean:** {entropy['mean']:.2f} (ideal: ~127.5)\n") f.write(f"- **Variance:** {entropy['variance']:.2f}\n") f.write(f"- **Chi-Square:** {entropy['chi_square']:.2f}\n\n")

        # Dieharder results dh = test_data["dieharder_tests"]
        if dh.get("success", False): tests = dh.get("tests", []) passed = len([t
        for t in tests
        if t.get("result") == "PASSED"]) failed = len([t
        for t in tests
        if t.get("result") == "FAILED"]) weak = len([t
        for t in tests
        if t.get("result") == "WEAK"]) total = len(tests) f.write("##

        # Dieharder Statistical Tests\n") f.write(f"- **Total Tests:** {total}\n") f.write(f"- **Passed:** {passed} ({passed/total*100:.1f}%)\n") f.write(f"- **Weak:** {weak} ({weak/total*100:.1f}%)\n") f.write(f"- **Failed:** {failed} ({failed/total*100:.1f}%)\n") f.write(f"- **Duration:** {dh['duration_seconds']:.1f} seconds\n\n")
        else: f.write("##

        # Dieharder Statistical Tests\n") f.write(f"- **Status:** FAILED - {dh.get('error', 'Unknown error')}\n\n") f.write("#

        # Interpretation\n\n") f.write("- **Shannon Entropy close to 8.0:** Good randomness\n") f.write("- **Mean close to 127.5:** Uniform byte distribution\n") f.write("- **Dieharder pass rate >95%:** Excellent statistical properties\n") f.write("- **Dieharder pass rate 90-95%:** Good statistical properties\n") f.write("- **Dieharder pass rate <90%:** May indicate statistical weaknesses\n\n") f.write("---\n") f.write("*Generated by QuantoniumOS RFT Crypto Statistical Test Suite*\n")
        print(f"📋 Summary report saved to: {report_file}")
    def main(): """
        Main execution function
"""
"""
        print(" COMPREHENSIVE RFT CRYPTOGRAPHIC STATISTICAL TESTING")
        print("="*70)

        # Configure test parameters sample_size_mb = 25 # 25MB should be sufficient for reliable statistical tests
        print(f"Initializing test suite with {sample_size_mb}MB sample size...")
        print("This will test your actual working RFT crypto implementations.")
        print("="*70) tester = ComprehensiveRFTCryptoTester(sample_size_mb=sample_size_mb) results = tester.run_full_test_suite()
        print("||n🎉 STATISTICAL TESTING COMPLETE!")
        print("="*70)
        print("Your RFT-based cryptographic implementations have been subjected to")
        print("rigorous statistical analysis using industry-standard test suites.")
        print("Check the generated reports for detailed analysis.")

if __name__ == "__main__": main()