||#!/usr/bin/env python3
"""
Branch Cut Continuity Regression Test Suite === This test suite ensures that the safe_log_unitary function maintains path-continuity across the branch cut at ±pi and never regresses to the problematic ~2.0 gap behavior. Tests: 1. Phase continuity across ±pi boundary 2. Smooth eigenvalue tracking through branch cut 3. Reconstruction error consistency 4. No discontinuous jumps in extracted phases 5. Regression prevention with edge cases
"""
"""

import numpy as np
import scipy.linalg
import matplotlib matplotlib.use('Agg')

# Non-interactive backend
import matplotlib.pyplot as plt from typing
import Tuple, List, Dict
import warnings from test_unitarity
import safe_log_unitary

class BranchCutContinuityValidator:
"""
"""
    Validates branch cut continuity and prevents regression.
"""
"""

    def __init__(self, tolerance: float = 1e-14):
        self.tolerance = tolerance
        self.results = {}
    def test_phase_continuity_fine_grid(self) -> Dict:
"""
"""
        Test 1: Fine-grained phase continuity across ±pi Creates a very fine grid of phases around the branch cut and ensures smooth, continuous behavior.
"""
"""
        print("Testing fine-grained phase continuity...")

        # Create very fine grid around critical regions critical_regions = [ np.linspace(-np.pi - 0.1, -np.pi + 0.1, 100),

        # Around -pi np.linspace(np.pi - 0.1, np.pi + 0.1, 100),

        # Around +pi np.linspace(-0.1, 0.1, 50),

        # Around 0 ] all_phases = np.concatenate(critical_regions) all_phases = np.unique(all_phases)

        # Remove duplicates and sort reconstruction_errors = [] extracted_phases = [] continuity_violations = 0 max_phase_jump = 0.0 prev_extracted_phase = None
        for phase in all_phases:

        # Create diagonal unitary with this phase U = np.diag([np.exp(1j * phase), np.exp(-1j * phase)])

        # Extract Hamiltonian H = safe_log_unitary(U, project_to_unitary=False)

        # Reconstruct and measure error U_recon = scipy.linalg.expm(-1j * H) error = np.linalg.norm(U - U_recon) reconstruction_errors.append(error)

        # Extract phase from Hamiltonian for continuity check H_eigenvals = np.linalg.eigvals(H)

        # Sort eigenvalues to ensure consistent tracking H_eigenvals_sorted = np.sort(H_eigenvals)

        # For continuity, track the eigenvalue that varies most smoothly

        # Choose based on proximity to previous value to handle eigenvalue crossings
        if prev_extracted_phase is None: current_phase = np.max(H_eigenvals_sorted)

        # Initialize with max
        else:

        # Choose eigenvalue closest to previous to maintain continuity distances = [abs(eig - prev_extracted_phase)
        for eig in H_eigenvals_sorted] min_distance_idx = np.argmin(distances) current_phase = H_eigenvals_sorted[min_distance_idx] extracted_phases.append(current_phase)

        # Check for discontinuous jumps with branch cut awareness
        if prev_extracted_phase is not None: phase_diff = abs(current_phase - prev_extracted_phase)

        # Handle wrapping around ±pi:
        if jump > pi, it might be wrapping
        if phase_diff > np.pi:

        # Check
        if this is legitimate wrapping vs. discontinuity wrapped_diff = 2*np.pi - phase_diff
        if wrapped_diff < phase_diff: phase_diff = wrapped_diff max_phase_jump = max(max_phase_jump, phase_diff)

        # Flag violation
        if jump is too large for adjacent phases phase_spacing = abs(phase - prev_input_phase) if 'prev_input_phase' in locals() else 0.01 expected_max_jump = 3 * phase_spacing

        # More generous tolerance for eigenvalue tracking

        # Only flag as violation
        if it's clearly discontinuous (not just eigenvalue reordering)
        if phase_diff > expected_max_jump and phase_diff > 0.5: continuity_violations += 1 prev_extracted_phase = current_phase prev_input_phase = phase max_error = max(reconstruction_errors) error_std = np.std(reconstruction_errors) result = { 'test_name': 'Fine-Grained Phase Continuity', 'num_points': len(all_phases), 'max_reconstruction_error': float(max_error), 'error_standard_deviation': float(error_std), 'continuity_violations': continuity_violations, 'max_phase_jump': float(max_phase_jump), 'passes': (max_error <
        self.tolerance and continuity_violations == 0 and max_phase_jump < 1.0)

        # More generous tolerance for eigenvalue tracking }
        print(f" Points tested: {result['num_points']}")
        print(f" Max reconstruction error: {result['max_reconstruction_error']:.2e}")
        print(f" Continuity violations: {result['continuity_violations']}")
        print(f" Max phase jump: {result['max_phase_jump']:.3f}")
        self.results['fine_continuity'] = result
        return result
    def test_branch_cut_crossing_sequences(self) -> Dict: """
        Test 2: Explicit branch cut crossing sequences Tests sequences that explicitly cross ±pi to ensure no discontinuous behavior.
"""
"""
        print("Testing branch cut crossing sequences...")

        # Define crossing sequences crossing_sequences = [

        # Cross +pi from below np.linspace(np.pi - 0.2, np.pi + 0.2, 50),

        # Cross -pi from above np.linspace(-np.pi + 0.2, -np.pi - 0.2, 50),

        # Full sweep through both cuts np.linspace(-np.pi - 0.1, np.pi + 0.1, 100), ] sequence_results = [] for seq_idx, phase_sequence in enumerate(crossing_sequences): reconstruction_errors = [] phase_jumps = [] prev_H_phase = None
        for phase in phase_sequence: U = np.diag([np.exp(1j * phase), np.exp(-1j * phase)]) H = safe_log_unitary(U, project_to_unitary=False) U_recon = scipy.linalg.expm(-1j * H) error = np.linalg.norm(U - U_recon) reconstruction_errors.append(error)

        # Track phase continuity H_eigenvals = np.linalg.eigvals(H) current_H_phase = np.max(H_eigenvals)
        if prev_H_phase is not None: phase_jump = abs(current_H_phase - prev_H_phase)

        # Handle wrapping
        if phase_jump > np.pi: phase_jump = 2*np.pi - phase_jump phase_jumps.append(phase_jump) prev_H_phase = current_H_phase max_error = max(reconstruction_errors) max_jump = max(phase_jumps)
        if phase_jumps else 0.0 seq_result = { 'sequence_index': seq_idx, 'max_error': float(max_error), 'max_phase_jump': float(max_jump), 'passes': max_error <
        self.tolerance and max_jump < 0.3 } sequence_results.append(seq_result)
        print(f" Sequence {seq_idx}: max_error={max_error:.2e}, max_jump={max_jump:.3f}") all_pass = all(seq['passes']
        for seq in sequence_results) result = { 'test_name': 'Branch Cut Crossing Sequences', 'sequences': sequence_results, 'all_sequences_pass': all_pass, 'passes': all_pass }
        self.results['crossing_sequences'] = result
        return result
    def test_eigenvalue_tracking_continuity(self) -> Dict: """
        Test 3: Eigenvalue tracking continuity Ensures that as we vary phases continuously, the eigenvalues of the extracted Hamiltonian also vary continuously.
"""
"""
        print("Testing eigenvalue tracking continuity...")

        # Create smooth phase trajectory that crosses branch cuts t = np.linspace(0, 4*np.pi, 200)

        # Two full cycles phase_trajectory = 0.95 * np.pi * np.sin(t)

        # Oscillates near ±pi eigenval_sequences = [[], []]

        # Track both eigenvalues reconstruction_errors = []
        for phase in phase_trajectory: U = np.diag([np.exp(1j * phase), np.exp(-1j * phase)]) H = safe_log_unitary(U, project_to_unitary=False) U_recon = scipy.linalg.expm(-1j * H) error = np.linalg.norm(U - U_recon) reconstruction_errors.append(error)

        # Track eigenvalue evolution H_eigenvals = np.sort(np.linalg.eigvals(H)) eigenval_sequences[0].append(H_eigenvals[0]) eigenval_sequences[1].append(H_eigenvals[1])

        # Compute eigenvalue derivatives (discrete) eigenval_derivatives = []
        for seq in eigenval_sequences: derivatives = np.diff(seq) eigenval_derivatives.append(derivatives)

        # Check for discontinuous jumps in derivatives max_derivative_jump = 0.0
        for derivatives in eigenval_derivatives:

        # Look for sudden spikes in derivative magnitude derivative_diffs = np.diff(derivatives) max_derivative_jump = max(max_derivative_jump, np.max(np.abs(derivative_diffs))) max_error = max(reconstruction_errors) result = { 'test_name': 'Eigenvalue Tracking Continuity', 'trajectory_points': len(phase_trajectory), 'max_reconstruction_error': float(max_error), 'max_derivative_jump': float(max_derivative_jump), 'passes': (max_error <
        self.tolerance and max_derivative_jump < 1.0) }
        print(f" Trajectory points: {result['trajectory_points']}")
        print(f" Max reconstruction error: {result['max_reconstruction_error']:.2e}")
        print(f" Max derivative jump: {result['max_derivative_jump']:.3f}")
        self.results['eigenvalue_tracking'] = result
        return result
    def test_regression_prevention_edge_cases(self) -> Dict: """
        Test 4: Regression prevention with edge cases Tests specific edge cases that could cause regression to the old ~2.0 gap behavior.
"""
"""
        print("Testing regression prevention edge cases...") edge_cases = [

        # Exactly at branch cuts (np.pi, "Exactly +pi"), (-np.pi, "Exactly -pi"),

        # Very close to branch cuts (np.pi - 1e-15, "Near +pi (below)"), (np.pi + 1e-15, "Near +pi (above)"), (-np.pi - 1e-15, "Near -pi (below)"), (-np.pi + 1e-15, "Near -pi (above)"),

        # Multiple of pi (2*np.pi, "2pi"), (-2*np.pi, "-2pi"), (0.0, "Zero phase"),

        # Random problematic phases from previous issues (3.141592653589793, "pi to machine precision"), (-3.141592653589793, "-pi to machine precision"), ] edge_case_results = [] for phase, description in edge_cases:

        # Wrap phase to principal branch for input phase_wrapped = np.mod(phase + np.pi, 2*np.pi) - np.pi U = np.diag([np.exp(1j * phase_wrapped), np.exp(-1j * phase_wrapped)])
        try: H = safe_log_unitary(U, project_to_unitary=False) U_recon = scipy.linalg.expm(-1j * H) error = np.linalg.norm(U - U_recon)

        # Check
        if error indicates ~2.0 gap regression has_regression = error > 1.0 # ~2.0 gap gives errors ~1-2 case_result = { 'phase': float(phase), 'phase_wrapped': float(phase_wrapped), 'description': description, 'reconstruction_error': float(error), 'has_regression': has_regression, 'passes': error <
        self.tolerance } except Exception as e: case_result = { 'phase': float(phase), 'phase_wrapped': float(phase_wrapped), 'description': description, 'error': str(e), 'has_regression': True,

        # Exception indicates problem 'passes': False } edge_case_results.append(case_result) status = "✓ PASS"
        if case_result['passes'] else "❌ FAIL" if 'reconstruction_error' in case_result:
        print(f" {description}: {case_result['reconstruction_error']:.2e} {status}")
        else:
        print(f" {description}: ERROR - {case_result['error']} {status}") all_pass = all(case['passes']
        for case in edge_case_results) no_regression = not any(case['has_regression']
        for case in edge_case_results) result = { 'test_name': 'Regression Prevention Edge Cases', 'edge_cases': edge_case_results, 'all_cases_pass': all_pass, 'no_regression_detected': no_regression, 'passes': all_pass and no_regression }
        self.results['edge_cases'] = result
        return result
    def run_full_continuity_suite(self) -> Dict: """
        Run the complete branch cut continuity test suite.
"""
"""
        print("=" * 70)
        print("BRANCH CUT CONTINUITY REGRESSION TEST SUITE")
        print("Ensuring path-continuity across ±pi never regresses")
        print("=" * 70) suite_results = { 'suite_name': 'Branch Cut Continuity Validation', 'tolerance':
        self.tolerance, 'tests': {} }

        # Run all tests suite_results['tests']['fine_continuity'] =
        self.test_phase_continuity_fine_grid() suite_results['tests']['crossing_sequences'] =
        self.test_branch_cut_crossing_sequences() suite_results['tests']['eigenvalue_tracking'] =
        self.test_eigenvalue_tracking_continuity() suite_results['tests']['edge_cases'] =
        self.test_regression_prevention_edge_cases()

        # Overall assessment all_tests_pass = all(test['passes']
        for test in suite_results['tests'].values()) suite_results['overall_pass'] = all_tests_pass
        print("\n" + "=" * 70)
        if all_tests_pass:
        print("✓ ALL TESTS PASS - Branch cut continuity maintained")
        print(" No regression to ~2.0 gap behavior detected")
        else:
        print("❌ SOME TESTS FAIL - Potential regression detected")
        print("=" * 70)
        return suite_results
    def main(): """
        Run the branch cut continuity validation.
"""
        """ validator = BranchCutContinuityValidator(tolerance=1e-14) results = validator.run_full_continuity_suite()

        # Generate summary report
        print("||nDETAILED RESULTS SUMMARY:")
        print("-" * 50) for test_name, test_result in results['tests'].items(): status = "✓ PASS"
        if test_result['passes'] else "❌ FAIL"
        print(f"{test_result['test_name']}: {status}")

        # Show key metrics if 'max_reconstruction_error' in test_result:
        print(f" Max reconstruction error: {test_result['max_reconstruction_error']:.2e}") if 'continuity_violations' in test_result:
        print(f" Continuity violations: {test_result['continuity_violations']}") if 'max_phase_jump' in test_result:
        print(f" Max phase jump: {test_result['max_phase_jump']:.3f}")
        return results

if __name__ == "__main__": main()