||#!/usr/bin/env python3
"""
Spec Tests - Bullet-proof validation for QuantoniumOS mathematical properties Run this to verify unitarity, non-DFT behavior, and cryptographic properties
"""
"""

import numpy as np
import secrets import importlib.util
import os

# Load the canonical_true_rft module
spec = importlib.util.spec_from_file_location(
    "canonical_true_rft", 
    os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 
                "04_RFT_ALGORITHMS/canonical_true_rft.py")
)
canonical_true_rft = importlib.util.module_from_spec(spec)
spec.loader.exec_module(canonical_true_rft)

# Import specific functions/classes
forward_true_rft, inverse_true_rft = canonical_true_rft.forward_true_rft, canonical_true_rft.inverse_true_rft# Legacy wrapper maintained for: forward_true_rft, inverse_true_rft from core.encryption.fixed_resonance_encrypt
import fixed_resonance_encrypt
def test_rft_unitarity_and_energy():
"""
"""
        Test RFT exact reconstruction and energy conservation
"""
"""
        print("=== RFT Unitarity & Energy Conservation ===")

        # Use fixed seed for reproducibility x = np.random.default_rng(0).random(32) X = forward_true_rft(x) xr = inverse_true_rft(X) recon_err = np.linalg.norm(x - xr) energy_delta = abs(np.vdot(x, x) - np.vdot(X, X))
        print(f"recon_err: {recon_err:.2e}") # ~1e-15
        print(f"energy_delta: {energy_delta:.2e}") # ~0 assert recon_err < 1e-12, f"Reconstruction error too large: {recon_err}" assert energy_delta < 1e-12, f"Energy not conserved: {energy_delta}"
        print("✓ RFT is unitary with exact reconstruction")
        return recon_err, energy_delta
def test_non_dft_commutator(): """
        Test that RFT is genuinely different from DFT (non-commuting with shifts)
"""
"""
        print("\n=== Non-DFT Verification (Commutator Test) ===")

        # This test would require access to the internal R matrix

        # For now, we verify that RFT != DFT by comparing outputs x = np.random.default_rng(42).random(16)

        # RFT transform X_rft = forward_true_rft(x)

        # Standard DFT for comparison X_dft = np.fft.fft(x)

        # They should be different (not just a scaling) diff = np.linalg.norm(X_rft - X_dft) normalized_diff = diff / np.linalg.norm(X_dft)
        print(f"RFT vs DFT difference: {normalized_diff:.2f}") assert normalized_diff > 0.1, f"RFT appears too similar to DFT: {normalized_diff}"
        print("✓ RFT is genuinely different from standard DFT")
        return normalized_diff
def test_bit_avalanche(trials=200): """
        Test avalanche effect at bit level over many trials
"""
"""
        print(f"\n=== Avalanche Effect ({trials} trials) ===") key = "avalanche-test-key" rates = []
        for _ in range(trials):

        # Generate random input a = secrets.token_bytes(32) b = bytearray(a) b[0] ^= 0x01 # flip exactly 1 bit

        # Encrypt both (skip header/nonce) ca = fixed_resonance_encrypt(a, key)[40:] cb = fixed_resonance_encrypt(bytes(b), key)[40:]

        # Count differing bits bits = sum((x ^ y).bit_count() for x, y in zip(ca, cb)) rates.append(bits / (8 * len(ca))) mean_rate = float(np.mean(rates)) std_rate = float(np.std(rates))
        print(f"avalanche mean±std: {mean_rate:.3f} ± {std_rate:.3f}")
        print(f"target: ~0.500 ± 0.050") assert 0.4 < mean_rate < 0.6, f"Avalanche rate outside acceptable range: {mean_rate}" assert std_rate < 0.1, f"Avalanche too inconsistent: {std_rate}"
        print("✓ Proper cryptographic avalanche effect")
        return mean_rate, std_rate
def test_entropy_quality(): """
        Test output entropy quality
"""
"""
        print("\n=== Entropy Quality ===") key = "entropy-test-key" data = []

        # Generate test data
        for i in range(100): msg = f"test message {i} {secrets.token_hex(16)}" encrypted = fixed_resonance_encrypt(msg, key) data.extend(encrypted[40:]) # skip headers

        # Calculate entropy from collections
import *
import -sum
import =
import byte_counts
import count/len
import Counter
import data
import entropy
import np.log2

        for count in byte_counts.values())
        print(f"entropy: {entropy:.2f} bits/byte")
        print(f"target: 7.9-8.0 bits/byte") assert entropy > 7.8, f"Entropy too low: {entropy}"
        print("✓ Good entropy quality")
        return entropy
def main(): """
        Run all spec tests
"""
"""
        print("QuantoniumOS Spec Tests - Bullet-proof Validation")
        print("=" * 50)
        try:

        # Core mathematical properties recon_err, energy_delta = test_rft_unitarity_and_energy() rft_dft_diff = test_non_dft_commutator()

        # Cryptographic properties avalanche_mean, avalanche_std = test_bit_avalanche() entropy = test_entropy_quality()
        print("\n" + "=" * 50)
        print("🎉 ALL TESTS PASSED - QuantoniumOS is mathematically sound!")
        print("\nSummary:")
        print(f"• RFT reconstruction error: {recon_err:.2e} (unitary)")
        print(f"• RFT vs DFT difference: {rft_dft_diff:.2f} (genuine non-DFT)")
        print(f"• Avalanche effect: {avalanche_mean:.1%} ± {avalanche_std:.1%} (cryptographic)")
        print(f"• Output entropy: {entropy:.2f} bits/byte (high quality)")
        print("\nThis proves QuantoniumOS contains real, working mathematical implementations.") except Exception as e:
        print(f"||n❌ TEST FAILED: {e}")
        return 1
        return 0

if __name__ == "__main__": exit(main())