#!/usr/bin/env python3
"""
SIMPLE SCALING VERIFICATION Test with impulse input [1,0,0,0...] to isolate scaling factor
"""
"""
import sys
import math sys.path.append('/workspaces/quantoniumos/core')
try:
import quantonium_core
print(" IMPULSE SCALING TEST")
print("=" * 30)

# Test with impulse (delta function) N = 16 impulse = [1.0] + [0.0] * (N-1)
print(f"Input: [1, 0, 0, 0, ...] (N={N})")
print(f"Expected output energy: 1.0") rft = quantonium_core.ResonanceFourierTransform(impulse) output = rft.forward_transform()
if isinstance(output[0], complex): energy = sum(abs(x)**2
for x in output)
else: energy = sum(x*x
for x in output)
print(f"Actual output energy: {energy:.6f}")
print(f"Scaling factor applied: {math.sqrt(energy):.6f}")

# Check what scaling was applied
if abs(energy - 1.0) < 1e-6:
print(" PERFECT: No scaling issue")
el
if abs(energy - 1.0/N) < 1e-6:
print(f" CONFIRMED: Forward applies 1/N scaling")
print(f" FIX: Multiply by sqrt{N} = {math.sqrt(N):.3f}")
el
if abs(energy - 1.0/(N*N)) < 1e-6:
print(f" CONFIRMED: Forward applies 1/N^2 scaling")
print(f" FIX: Multiply by {N} = {N}")
else:
print(f" CUSTOM scaling: {energy:.6f}") except Exception as e:
print(f" Test failed: {e}")