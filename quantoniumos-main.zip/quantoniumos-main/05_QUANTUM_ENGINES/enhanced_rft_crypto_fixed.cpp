// CORRECTED enhanced_rft_crypto.cpp
// This is a corrected version with fixed Feistel decryption

#include "rft_crypto.h"
#include <vector>
#include <cmath>
#include <algorithm>
#include <numeric>
#include <cstring>
#include <stdexcept>

// === Minimal SHA-256 (big-endian) for key derivation ===
class SHA256 {
private:
    static constexpr uint32_t K[64] = {
        0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
    };
    
    static inline uint32_t rotr(uint32_t x, int n){ return (x>>n) | (x<<(32-n)); }
    static inline uint32_t ch (uint32_t x,uint32_t y,uint32_t z){ return (x&y) ^ (~x&z); }
    static inline uint32_t maj(uint32_t x,uint32_t y,uint32_t z){ return (x&y) ^ (x&z) ^ (y&z); }
    static inline uint32_t S0(uint32_t x){ return rotr(x,2) ^ rotr(x,13) ^ rotr(x,22); }
    static inline uint32_t S1(uint32_t x){ return rotr(x,6) ^ rotr(x,11) ^ rotr(x,25); }
    static inline uint32_t s0(uint32_t x){ return rotr(x,7) ^ rotr(x,18) ^ (x>>3); }
    static inline uint32_t s1(uint32_t x){ return rotr(x,17)^ rotr(x,19)^ (x>>10); }

public:
    static std::vector<uint8_t> hash(const std::vector<uint8_t>& data){
        uint32_t H[8] = {
            0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
            0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19
        };
        
        std::vector<uint8_t> m;
        m.reserve(data.size()+72);
        m.insert(m.end(), data.begin(), data.end());
        m.push_back(0x80);
        while ((m.size() % 64) != 56) m.push_back(0x00);
        
        uint64_t bitlen = static_cast<uint64_t>(data.size()) * 8ULL;
        for (int i=7;i>=0;--i) m.push_back(static_cast<uint8_t>((bitlen >> (i*8)) & 0xFF));
        
        for (size_t off=0; off<m.size(); off+=64){
            uint32_t w[64];
            for (int i=0;i<16;++i){
                size_t o = off + 4*i;
                w[i] = (static_cast<uint32_t>(m[o])<<24) | 
                       (static_cast<uint32_t>(m[o+1])<<16) | 
                       (static_cast<uint32_t>(m[o+2])<<8) | 
                       (static_cast<uint32_t>(m[o+3]));
            }
            
            for (int i=16;i<64;++i) w[i] = s1(w[i-2]) + w[i-7] + s0(w[i-15]) + w[i-16];
            
            uint32_t a=H[0],b=H[1],c=H[2],d=H[3],e=H[4],f=H[5],g=H[6],h=H[7];
            for (int i=0;i<64;++i){
                uint32_t t1 = h + S1(e) + ch(e,f,g) + K[i] + w[i];
                uint32_t t2 = S0(a) + maj(a,b,c);
                h=g; g=f; f=e; e=d + t1; d=c; c=b; b=a; a=t1 + t2;
            }
            H[0]+=a; H[1]+=b; H[2]+=c; H[3]+=d; H[4]+=e; H[5]+=f; H[6]+=g; H[7]+=h;
        }
        
        std::vector<uint8_t> out;
        out.reserve(32);
        for (int i=0;i<8;++i){
            out.push_back(static_cast<uint8_t>((H[i]>>24)&0xFF));
            out.push_back(static_cast<uint8_t>((H[i]>>16)&0xFF));
            out.push_back(static_cast<uint8_t>((H[i]>>8 )&0xFF));
            out.push_back(static_cast<uint8_t>((H[i]   )&0xFF));
        }
        return out;
    }
};

// === Enhanced RFT Feistel with CORRECTED DECRYPTION ===
class EnhancedRFTCrypto {
private:
    static constexpr double PHI = 1.6180339887498948482;
    static constexpr size_t ROUNDS = 48;
    static constexpr size_t ALIGN = 32;
    static constexpr size_t F_MIN = 16;

    // AES S-box
    static constexpr uint8_t SBOX[256] = {
        0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
        0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
        0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
        0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
        0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
        0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
        0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
        0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
        0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
        0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
        0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
        0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
        0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
        0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
        0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
        0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16
    };

    // Permutation tables
    static constexpr uint8_t PERM16[16][16] = {
        { 0, 7,14, 9,12,11, 2,15, 8, 1, 6, 5, 4, 3,10,13},
        {15, 0, 7,14, 9,12,11, 2, 5, 8, 1, 6,13,10, 3, 4},
        { 8,15, 0, 7,14, 9,12,11, 2, 5,10, 1, 6,13, 4, 3},
        { 2, 9, 4,15, 6,13, 8, 1,14, 3,12, 5,10, 7, 0,11},
        {10, 1, 6, 5, 4, 3,14,13,12,11, 2,15, 8, 7, 0, 9},
        { 6,13, 8, 1,14, 3,12, 5,10, 7, 0,11, 2, 9, 4,15},
        {12,11, 2,15, 8, 7, 0, 9, 6,13, 4, 1,14, 3,10, 5},
        { 4, 3,10,13, 0,15, 6, 1,12, 7,14, 9, 2, 5, 8,11},
        { 7,12, 5,10, 3,14, 1, 6,15, 0,13, 8,11, 2, 9, 4},
        {11, 4, 9, 2,15, 6,13, 8, 1,14, 5,12, 7,10, 3, 0},
        { 1, 8,15, 0, 7,10, 9,12,11, 2, 5, 6,13, 4,14, 3},
        {14, 7,12, 5,10, 1, 6,13, 0,15, 8,11, 2, 9, 4, 3},
        { 9, 2, 3, 4, 5, 6, 7, 8,13,10,11,12, 1,14,15, 0},
        { 5,10, 1, 6,13, 0,15, 8,11, 2, 9, 4,14, 7,12, 3},
        {13, 6,11, 4, 1, 8, 3,10, 7,12,15, 0, 9, 2, 5,14},
        { 3,14, 7,12, 5,10, 1, 6, 9, 4,13, 8,15, 0,11, 2}
    };

    // Cached schedule
    mutable std::vector<std::vector<uint8_t>> cached_round_keys;
    mutable std::vector<uint8_t> cached_pre_whiten;
    mutable std::vector<uint8_t> cached_post_whiten;
    mutable std::vector<uint8_t> cached_perm_idx;
    mutable std::vector<int> cached_rotations;
    mutable std::vector<int> cached_rot_a, cached_rot_b, cached_rot_c;
    mutable std::vector<uint32_t> cached_rc32;
    mutable std::vector<uint8_t> last_key;

    // GF(2^8) helpers
    static inline uint8_t xtime(uint8_t x){
        uint8_t m = static_cast<uint8_t>(-(x >> 7));
        return static_cast<uint8_t>((x << 1) ^ (m & 0x1B));
    }
    
    static inline uint8_t mul2(uint8_t x){ return xtime(x); }
    static inline uint8_t mul3(uint8_t x){ return static_cast<uint8_t>(xtime(x) ^ x); }

    // MixColumns
    static inline void mixcolumns_4x4(uint8_t s[16]){
        for (int c=0;c<4;++c){
            uint8_t *p = s + 4*c;
            uint8_t a0=p[0], a1=p[1], a2=p[2], a3=p[3];
            uint8_t r0 = static_cast<uint8_t>(mul2(a0) ^ mul3(a1) ^ a2 ^ a3);
            uint8_t r1 = static_cast<uint8_t>(a0 ^ mul2(a1) ^ mul3(a2) ^ a3);
            uint8_t r2 = static_cast<uint8_t>(a0 ^ a1 ^ mul2(a2) ^ mul3(a3));
            uint8_t r3 = static_cast<uint8_t>(mul3(a0) ^ a1 ^ a2 ^ mul2(a3));
            p[0]=r0; p[1]=r1; p[2]=r2; p[3]=r3;
        }
    }

    static inline uint32_t rotl32(uint32_t x, int r){
#if defined(_MSC_VER)
        return _rotl(x, r);
#else
        return (x<<r) | (x>>(32-r));
#endif
    }

    // Key schedule
    bool derive_keys_cached(const std::vector<uint8_t>& master_key) const {
        if (master_key == last_key && !cached_round_keys.empty()) return true;
        
        last_key = master_key;
        cached_round_keys.assign(ROUNDS, std::vector<uint8_t>());
        cached_rotations.clear(); cached_rotations.reserve(ROUNDS);
        cached_perm_idx.clear(); cached_perm_idx.reserve(ROUNDS);
        cached_rot_a.clear(); cached_rot_a.reserve(ROUNDS);
        cached_rot_b.clear(); cached_rot_b.reserve(ROUNDS);
        cached_rot_c.clear(); cached_rot_c.reserve(ROUNDS);
        cached_rc32.clear(); cached_rc32.reserve(ROUNDS);

        auto derive_subkey = [&](const std::string& domain, uint8_t ctr)->std::vector<uint8_t>{
            std::vector<uint8_t> in;
            in.reserve(master_key.size()+domain.size()+2);
            in.insert(in.end(), master_key.begin(), master_key.end());
            in.push_back(static_cast<uint8_t>(0xA5 ^ ctr));
            in.insert(in.end(), domain.begin(), domain.end());
            auto h = SHA256::hash(in);
            
            for (int i=0;i<3;++i){
                std::vector<uint8_t> x;
                x.reserve(h.size()+1);
                x.insert(x.end(), h.begin(), h.end());
                x.push_back(static_cast<uint8_t>(i+1));
                h = SHA256::hash(x);
            }
            return h;
        };

        // Pre/Post whitening
        auto pre = derive_subkey("PRE_WHITEN_RFT_2025", 0);
        auto post = derive_subkey("POST_WHITEN_RFT_2025", 1);
        cached_pre_whiten.assign(pre.begin(), pre.begin()+16);
        cached_post_whiten.assign(post.begin(), post.begin()+16);

        // Per-round keys
        for (size_t r=0; r<ROUNDS; ++r){
            auto rk = derive_subkey("RFT_ROUND_" + std::to_string(r) + "_PHI_" + std::to_string(static_cast<int>(PHI*1000)), static_cast<uint8_t>(r));
            
            for (size_t i=0;i<rk.size();++i){
                uint8_t phi_mix = static_cast<uint8_t>((i * r * PHI * 255.0) / (ROUNDS?ROUNDS:1)) & 0xFF;
                rk[i] ^= phi_mix;
            }
            
            cached_round_keys[r].assign(rk.begin(), rk.begin()+16);

            uint32_t rA = (static_cast<uint32_t>(rk[16])<<24) | (rk[17]<<16) | (rk[18]<<8) | rk[19];
            uint32_t rB = (static_cast<uint32_t>(rk[20])<<24) | (rk[21]<<16) | (rk[22]<<8) | rk[23];
            uint32_t rC = (static_cast<uint32_t>(rk[24])<<24) | (rk[25]<<16) | (rk[26]<<8) | rk[27];
            
            cached_rot_a.push_back(static_cast<int>((rA % 32u) + 1u));
            cached_rot_b.push_back(static_cast<int>((rB % 32u) + 1u));
            cached_rot_c.push_back(static_cast<int>((rC % 32u) + 1u));

            uint64_t rot_seed=0;
            for (int i=0;i<8;++i) rot_seed = (rot_seed<<8) | rk[16+i];
            rot_seed ^= static_cast<uint64_t>(static_cast<double>(r) * PHI * 1000000.0);
            cached_rotations.push_back(static_cast<int>((rot_seed % 32ULL) + 1ULL));

            uint8_t pidx = static_cast<uint8_t>((rk[28] ^ rk[5] ^ rk[11] ^ rk[3]) & 0x0F);
            cached_perm_idx.push_back(pidx);

            uint32_t rc = (static_cast<uint32_t>(rk[0])<<24) | (rk[1]<<16) | (rk[2]<<8) | rk[3];
            cached_rc32.push_back(rc);
        }
        return false;
    }

    // Enhanced F-function
    inline void enhanced_f_function_fast(const uint8_t* in, size_t in_len, 
                                       const std::vector<uint8_t>& round_key, 
                                       int rot_primary, uint8_t perm_idx, 
                                       uint8_t* out) const {
        alignas(32) uint8_t state[32];
        const size_t L = (in_len > 32 ? 32 : in_len);
        std::memcpy(state, in, L);
        if (L < 32) std::memset(state+L, 0, 32-L);

        // PHI positional stir
        for (size_t i=0;i<L;++i){
            uint32_t t = static_cast<uint32_t>((i+1) * 2654435761u);
            state[i] ^= static_cast<uint8_t>(t);
        }

        // Key inject #1
        for (size_t i=0;i<L;++i) state[i] ^= round_key[i % round_key.size()];

        // ARX on first 16 bytes
        if (L >= 16){
            uint32_t w0,w1,w2,w3;
            std::memcpy(&w0, state+ 0, 4); std::memcpy(&w1, state+ 4, 4);
            std::memcpy(&w2, state+ 8, 4); std::memcpy(&w3, state+12, 4);

            int rA = rot_primary;
            int rB = ((state[5] & 31) ? (state[5] & 31) : 1);
            int rC = ((state[11] & 31) ? (state[11] & 31) : 1);

            auto qr = [&](int ra, int rb){
                w0 += w1; w3 ^= w0; w3 = rotl32(w3, ra);
                w2 += w3; w1 ^= w2; w1 = rotl32(w1, rb);
            };

            qr(rA, rB);
            w1 += w2; w0 ^= w1; w0 = rotl32(w0, rC);
            w3 += w0; w2 ^= w3; w2 = rotl32(w2, (rA+11)&31 ? (rA+11)%32 : 1);
            qr(rB, rC);
            w1 += w2; w0 ^= w1; w0 = rotl32(w0, (rB+13)&31 ? (rB+13)%32 : 1);
            w3 += w0; w2 ^= w3; w2 = rotl32(w2, (rC+18)&31 ? (rC+18)%32 : 1);

            std::memcpy(state+ 0, &w0, 4); std::memcpy(state+ 4, &w1, 4);
            std::memcpy(state+ 8, &w2, 4); std::memcpy(state+12, &w3, 4);
        }

        // S-box layer
        for (size_t i=0;i<L;++i) state[i] = SBOX[state[i]];

        // Linear diffusion
        if (L >= 16){
            mixcolumns_4x4(state);
            
            // ShiftRows
            uint8_t t;
            t=state[1]; state[1]=state[5]; state[5]=state[9]; state[9]=state[13]; state[13]=t;
            std::swap(state[2], state[10]); std::swap(state[6], state[14]);
            t=state[15]; state[15]=state[11]; state[11]=state[7]; state[7]=state[3]; state[3]=t;
        }

        // Key inject #2
        if (L >= 16){
            uint32_t rc;
            std::memcpy(&rc, &round_key[0], 4);
            uint32_t* lw = reinterpret_cast<uint32_t*>(state);
            lw[0] += rc; lw[1] += rotl32(rc, 7); lw[2] += rotl32(rc, 13); lw[3] += rotl32(rc, 19);
        }

        // Permutation
        if (L > 1){
            alignas(32) uint8_t tmp[32];
            const uint8_t* P = PERM16[perm_idx & 0x0F];
            if (L >= 16){
                for (int i=0;i<16;++i) tmp[P[i]] = state[i];
                std::memcpy(state, tmp, 16);
            } else {
                for (size_t i=0;i<L; ++i){
                    size_t src = i & 15;
                    size_t dst = P[src] % L;
                    tmp[dst] = state[i];
                }
                std::memcpy(state, tmp, L);
            }
        }

        std::memcpy(out, state, L);
    }

    static inline void xor_bytes(uint8_t* dst, const uint8_t* src, size_t n){
        for (size_t i=0;i<n;++i) dst[i] ^= src[i];
    }

    inline void pre_whiten(uint8_t* b, size_t n) const {
        const size_t m = std::min(n, cached_pre_whiten.size());
        for (size_t i=0;i<m;++i) b[i] ^= cached_pre_whiten[i];
    }

    inline void post_whiten(uint8_t* b, size_t n) const {
        const size_t m = std::min(n, cached_post_whiten.size());
        for (size_t i=0;i<m;++i) b[i] ^= cached_post_whiten[i];
    }

public:
    std::vector<uint8_t> encrypt(const std::vector<uint8_t>& plaintext, const std::vector<uint8_t>& key) const {
        if (plaintext.size() % 2 != 0) throw std::invalid_argument("Plaintext size must be even for Feistel");
        
        derive_keys_cached(key);
        const size_t half = plaintext.size()/2;
        
        std::vector<uint8_t> L(plaintext.begin(), plaintext.begin()+half);
        std::vector<uint8_t> R(plaintext.begin()+half, plaintext.end());

        // Pre-whitening
        pre_whiten(L.data(), half);
        pre_whiten(R.data(), half);

        // Feistel rounds
        std::vector<uint8_t> Fout(half);
        for (size_t r=0; r<ROUNDS; ++r){
            enhanced_f_function_fast(R.data(), half, cached_round_keys[r], 
                                   cached_rotations[r], cached_perm_idx[r], Fout.data());
            xor_bytes(L.data(), Fout.data(), half);
            if (r < ROUNDS-1) L.swap(R);  // Don't swap on last round
        }

        // Post-whitening
        post_whiten(L.data(), half);
        post_whiten(R.data(), half);

        std::vector<uint8_t> C;
        C.reserve(plaintext.size());
        C.insert(C.end(), L.begin(), L.end());
        C.insert(C.end(), R.begin(), R.end());
        return C;
    }

    std::vector<uint8_t> decrypt(const std::vector<uint8_t>& ciphertext, const std::vector<uint8_t>& key) const {
        if (ciphertext.size() % 2 != 0) throw std::invalid_argument("Ciphertext size must be even for Feistel");
        
        derive_keys_cached(key);
        const size_t half = ciphertext.size()/2;
        
        std::vector<uint8_t> L(ciphertext.begin(), ciphertext.begin()+half);
        std::vector<uint8_t> R(ciphertext.begin()+half, ciphertext.end());

        // *** CORRECTED DECRYPTION: Reverse post-whitening FIRST ***
        post_whiten(L.data(), half);
        post_whiten(R.data(), half);

        // *** CORRECTED FEISTEL ROUNDS: Proper reverse order ***
        std::vector<uint8_t> Fout(half);
        for (int r = static_cast<int>(ROUNDS)-1; r>=0; --r){
            // *** KEY FIX: Swap BEFORE F-function (except first decrypt round) ***
            if (r < static_cast<int>(ROUNDS)-1) L.swap(R);
            
            enhanced_f_function_fast(R.data(), half, cached_round_keys[r], 
                                   cached_rotations[r], cached_perm_idx[r], Fout.data());
            xor_bytes(L.data(), Fout.data(), half);
        }

        // *** CORRECTED: Reverse pre-whitening LAST ***
        pre_whiten(L.data(), half);
        pre_whiten(R.data(), half);

        std::vector<uint8_t> P;
        P.reserve(ciphertext.size());
        P.insert(P.end(), L.begin(), L.end());
        P.insert(P.end(), R.begin(), R.end());
        return P;
    }
};

// === C interface ===
extern "C" {
    EnhancedRFTCrypto* create_enhanced_rft(){
        return new EnhancedRFTCrypto();
    }

    void destroy_enhanced_rft(EnhancedRFTCrypto* c){
        delete c;
    }

    int encrypt_enhanced_rft(EnhancedRFTCrypto* c, const uint8_t* pt, size_t pt_len, 
                           const uint8_t* key, size_t key_len, uint8_t* ct, size_t* ct_len) {
        try{
            std::vector<uint8_t> PT(pt, pt+pt_len);
            std::vector<uint8_t> K(key, key+key_len);
            auto out = c->encrypt(PT, K);
            if (*ct_len < out.size()){
                *ct_len = out.size();
                return -1;
            }
            std::memcpy(ct, out.data(), out.size());
            *ct_len = out.size();
            return 0;
        } catch (...) {
            return -2;
        }
    }

    int decrypt_enhanced_rft(EnhancedRFTCrypto* c, const uint8_t* ct, size_t ct_len, 
                           const uint8_t* key, size_t key_len, uint8_t* pt, size_t* pt_len) {
        try{
            std::vector<uint8_t> CT(ct, ct+ct_len);
            std::vector<uint8_t> K(key, key+key_len);
            auto out = c->decrypt(CT, K);
            if (*pt_len < out.size()){
                *pt_len = out.size();
                return -1;
            }
            std::memcpy(pt, out.data(), out.size());
            *pt_len = out.size();
            return 0;
        } catch (...) {
            return -2;
        }
    }
}
