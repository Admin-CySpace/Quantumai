"""
QuantoniumOS Routes Package

Web routing and API endpoint definitions for QuantoniumOS.
Contains route handlers and API implementations.
"""

__version__ = "1.0.0"
