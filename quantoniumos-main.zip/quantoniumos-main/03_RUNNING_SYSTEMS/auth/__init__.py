"""
QuantoniumOS Auth Package

Authentication and authorization components for QuantoniumOS.
Contains user management, token handling, and security features.
"""

__version__ = "1.0.0"
