"""
QuantoniumOS Middleware Package

Middleware components for request processing, security,
and system-level operations in QuantoniumOS.
"""

__version__ = "1.0.0"
